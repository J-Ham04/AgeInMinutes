package jh.development.ageinminutescalculator

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private var selectedDate : TextView? = null
    private var dateInMin : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSelDate : Button = findViewById<Button>(R.id.selectDateButton)
        selectedDate = findViewById(R.id.dateDisplay)
        dateInMin = findViewById(R.id.dateInMin)

        btnSelDate.setOnClickListener{
            clickSelectDate()
            btnSelDate.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
        }
    }

    private fun clickSelectDate(){


        val myCalendar = Calendar.getInstance()
        val year = myCalendar.get(Calendar.YEAR)
        val month = myCalendar.get(Calendar.MONTH)
        val day = myCalendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this,
            DatePickerDialog.OnDateSetListener{
                view, year, month,dayOfMonth ->
                val selectedDateVar = "${month+1}.$dayOfMonth.$year"

                selectedDate?.text = selectedDateVar

                val sdf = SimpleDateFormat("MM.dd.yyyy", Locale.CANADA)
                //Selected date in minutes
                val theDate = sdf.parse(selectedDateVar)
                val selectedDateInMin = theDate.time / 60000
                //current cate in minutes
                val currentDate = sdf.parse(sdf.format(System.currentTimeMillis()))
                val currentDateInMinutes : Long = currentDate.time / 60000

                val differenceInMinutes = currentDateInMinutes - selectedDateInMin

                dateInMin?.text = differenceInMinutes.toString()
            },
            year, month, day).show()
    }
}